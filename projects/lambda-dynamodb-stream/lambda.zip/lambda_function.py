def lambda_handler(event, context):
    print("Hello from Lambda!")
    print("Event:", event)
    return {
        "statusCode": 200,
        "body": "Lambda executed successfully!"
    }
